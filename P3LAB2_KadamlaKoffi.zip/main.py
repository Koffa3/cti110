desired_service=input('Enter desired auto service:\n')
print("You entered:",desired_service) # print what user enters

if(desired_service)=="Oil change":# if disired service is oil change whith ignorance of case
    print("Cost of oil change: $35")
elif(desired_service)=="Tire rotation": # ignore case so converts to lower tire rotation
    print("Cost of tire rotation: $19")
elif (desired_service)=="Car wash": 
    print("Cost of car wash: $7")
else: # else case
    print("Error: Requested service is not recognized") #remaining error